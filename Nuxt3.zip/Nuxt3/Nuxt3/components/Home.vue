<!-- Please remove this file from your project -->
<template>
  <div>
    <div>Nuxt3 Basic</div>
  </div>
</template>

