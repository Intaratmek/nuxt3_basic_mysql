<template>
    <Login />
</template>
<!--
<style>
.page-enter-active,
.page-leave-active {
    transition: all 0.1s;
}

.page-enter-from,
.page-leave-to {
    opacity: 0;
    filter: blur(0.3rem);
}
</style>
-->
<script setup>

useHead({
    title: "Nuxt3 Basic | ล็อคอิน",
    meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {
            hid: "Nuxt3 Basic | ล็อคอิน",
            name: "Nuxt3 Basic | ล็อคอิน",
            content: "Nuxt3 Basic | ล็อคอิน",
        },
    ],
})
</script>