<template>
  <ResetPassword />
</template>


<script setup s>

useHead({
  title: "Nuxt3 Basic | ลืมรหัสผ่าน",
  meta: [
    // hid is used as unique identifier. Do not use `vmid` for it as it will not work
    {
      hid: "Nuxt3 Basic | ลืมรหัสผ่าน",
      name: "Nuxt3 Basic | ลืมรหัสผ่าน",
      content: "Nuxt3 Basic | ลืมรหัสผ่าน",
    },
  ],
})
</script>
