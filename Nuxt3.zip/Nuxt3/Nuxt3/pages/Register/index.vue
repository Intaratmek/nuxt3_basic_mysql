<template>
  <Register />
</template>


<script setup>


useHead({
  title: "Nuxt3 Basic | ลงทะเบียน",
  meta: [
    // hid is used as unique identifier. Do not use `vmid` for it as it will not work
    {
      hid: "Nuxt3 Basic | ลงทะเบียน",
      name: "Nuxt3 Basic | ลงทะเบียน",
      content: "Nuxt3 Basic | ลงทะเบียน",
    },
  ],
})
</script>
